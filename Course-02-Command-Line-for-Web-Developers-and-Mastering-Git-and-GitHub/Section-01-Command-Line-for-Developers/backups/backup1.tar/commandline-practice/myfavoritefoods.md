Apple, Yoghurt, Nuts
